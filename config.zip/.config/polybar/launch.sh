#!/usr/bin/env bash

# Launch the bar
STYLE="vintagebirds"

bash "$HOME"/.config/polybar/"$STYLE"/launch.sh
